// Rob Smookler, Sean Flaherty
// Project 5A

//This file contains the main function for part A of project 5.

#include <iostream>
#include "stdafx.h"
#include <limits.h>
#include <list>
#include <fstream>
#include <conio.h>
#include "maze.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	//File stream to read from text files
    ifstream fin1;
	ifstream fin2;
	ifstream fin3;

	//Declare file names to open maze files
    string fileName1 = "maze1.txt";
	string fileName2 = "maze2.txt";
	string fileName3 = "maze3.txt";

    //Maze 1
    try
    {
	  //Create a graph for each path-finding algorithm
      graph g1a;
	  graph g1b;

	  //Open file 1
	  fin1.open(fileName1.c_str());

      if (!fin1)
      {
        cerr << "Cannot open " << fileName1 << endl;
        exit(1);
      }//end if

      while (fin1 && fin1.peek() != 'Z')
      {
		 //Declare maze
         maze m(fin1);

		 //Map maze to both graphs
         m.mapMazeToGraph(g1a);
		 m.mapMazeToGraph(g1b);

		 //Recursive path finding algorithm
         m.findPath(0,0, g1a);
		 cout << "\n\n";

		 //Non-recursive path finding algorithm
         m.findPathNonRec(g1b);
		 cout << "\n\n";
      }//end while
    }
    catch (indexRangeError &ex)
    {
      cout << ex.what() << endl;
	  exit(1);
    }
    catch (rangeError &ex)
    {
      cout << ex.what() << endl;
	  exit(1);
    }//end try-catch 1
	
    //Maze 2
    try 
    {
	  //Create a graph for each path-finding algorithm
      graph g2a;
	  graph g2b;

	  //Open file 2
      fin2.open(fileName2.c_str());

	  if (!fin2)
	  {
		cerr << "Cannot open " << fileName1 << endl;
        exit(1);
      }//end if

      while (fin2 && fin2.peek() != 'Z')
      {
		 //Declare maze
         maze m(fin2);

		 //Map maze to both graphs
         m.mapMazeToGraph(g2a);
		 m.mapMazeToGraph(g2b);

		 //Recursive path-finding algorithm
         m.findPath(0,0, g2a);
		 cout << "\n\n";

		 //Non-recursive path-finding algorithm
         m.findPathNonRec(g2b);
		 cout << "\n\n";
      }//end while
    }
    catch (indexRangeError &ex)
    {
       cout << ex.what() << endl; exit(1);
    }
    catch (rangeError &ex)
    {
       cout << ex.what() << endl; exit(1);
    }//end try-catch 2

	//Maze 3
    try 
    {
	  //Create a graph for each path-finding algorithm
      graph g3a;
	  graph g3b;

	  //Open maze file
      fin3.open(fileName3.c_str());

	  if (!fin3)
	  {
		cerr << "Cannot open " << fileName1 << endl;
        exit(1);
      }//end if

      while (fin3 && fin3.peek() != 'Z')
      {
		 //Declare maze
         maze m(fin3);
         m.mapMazeToGraph(g3a);
		 m.mapMazeToGraph(g3b);

		 //Recursive path-finding algorithm
         m.findPath(0,0, g3a);
         cout << "\n\n";

		 //Non-recursive path-finding algorithm
         m.findPathNonRec(g3b);
      }//end while
    }
    catch (indexRangeError &ex)
    {
       cout << ex.what() << endl; exit(1);
    }
    catch (rangeError &ex)
    {
       cout << ex.what() << endl; exit(1);
    }//end try-catch 3
    
	//Wait for character input by user before terminating program
	cout << "\n\nPress any key to continue...";
	getch();

	return 0;
}//end main

//End of source file.

