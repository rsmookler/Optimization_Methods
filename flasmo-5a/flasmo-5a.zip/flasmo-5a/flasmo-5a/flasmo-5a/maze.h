// Rob Smookler, Sean Flaherty
// Project 5A

//This file contains the maze class declaration,
//as well as all of its member functions.

#include "graph.h"

using namespace std;

class maze
{
public:
      maze(ifstream &fin);                                 //Constructor 
      void print(int,int,int,int);                         //Print maze
      bool isLegal(int i, int j);                          //Determine if move is legal
      void setMap(int i, int j, int n);                    //Set map 
      int getMap(int i, int j) const;                      //Get map
      void mapMazeToGraph(graph &g);                       //Map maze to graph class
      void findPath(int currentX, int currentY, graph &g); //Recursive path finder
	  void findPathNonRec(graph &g);					   //Non-recursive path finder
private:
      int rows;											   //Number of rows in the maze
      int cols;											   //Number of columns in the maze
      matrix<bool> value;								   //Matrix of maze values
      matrix<int> map;								       // Mapping from maze (i,j) values to node index values
};

void maze::setMap(int i, int j, int n)
// Set mapping from maze cell (i,j) to graph node n
{
    map[i][j] = n;
    return ;
}//end setMap

int maze::getMap(int i, int j) const
// Return mapping of maze cell (i,j) in the graph.
{
    return map[i][j];
}//end getMap

maze::maze(ifstream &fin)
// Initializes a maze by reading values from fin.  Assumes that the
// number of rows and columns indicated in the file are correct.
{
   //Read number of rows and columns from file and resize matrices
   fin >> rows;
   fin >> cols;
   value.resize(rows,cols);
   map.resize(rows,cols);

   //Character variable to read in maze values
   char c;

   //Assign values for the maze
   for (int i = 0; i < rows; i++)
   {
      for (int j = 0; j < cols; j++)
      {
		 fin >> c;

		 if (c == 'O')
		 {
            value[i][j] = true;
		 }
		 else
		 {
			value[i][j] = false;
		 }//end if
      }//end inner for
   }//end outer for
}//end constructor

void maze::print(int goalI, int goalJ, int currI, int currJ)
// Print out a maze, with the goal and current cells marked on the
// board.
{
   cout << endl;

   if (goalI < 0 || goalI > rows || goalJ < 0 || goalJ > cols)
      throw rangeError("Bad value in maze::print");

   if (currI < 0 || currI > rows || currJ < 0 || currJ > cols)
      throw rangeError("Bad value in maze::print");

   for (int i = 0; i <= rows-1; i++)
   {
      for (int j = 0; j <= cols-1; j++)
      {
	  if (i == goalI && j == goalJ)
	    cout << "*";
	  else
	    if (i == currI && j == currJ)
	       cout << "+";
	    else
	       if (value[i][j])
		  cout << " ";
	       else
		  cout << "X";
      }
      cout << endl;
   }
   cout << endl;
}//end print

bool maze::isLegal(int i, int j)
// Return the value stored at the (i,j) entry in the maze.
{
   if (i < 0 || i > rows || j < 0 || j > cols)
      throw rangeError("Bad value in maze::isLegal");

   return value[i][j];
}//end isLegal

void maze::mapMazeToGraph(graph &g)
// Create a graph g that represents the legal moves in the maze m.
{
    int nodeNumber = -1;
    int nodeKey;

    for (int j = 0; j < rows; j++)
	{
      for (int k = 0; k < cols; k++)
      {
		  //If the cell is valid, create a new node with weight 1 and add to graph
          if (value[j][k] == true)
          {
			  //Create a new node, set ID and weight, and add to graph
              nodeNumber++;
              node newNode = node();
              newNode.setId(nodeNumber);
              newNode.setWeight(1);
              g.addNode(newNode);

			  //Store node number on map
              map[j][k] = nodeNumber;
			 
			  //If we are outside the first column, check left for a valid edge
              if (k > 0)
              {
				  //If the cell to the left is valid, add edges
                  if (value[j][k-1])
                  {
                      nodeKey = map[j][k-1];
                      g.addEdge(nodeKey, nodeNumber, 1);
                      g.addEdge(nodeNumber, nodeKey, 1);
                  }//end if
              }//end if

			  //If we are outside the first row, check up for a valid edge 
              if (j > 0)
              {
				  //If the cell above is valid, add edges 
                  if (value[j-1][k])
                  {
                      nodeKey = map[j-1][k];
                      g.addEdge(nodeKey, nodeNumber, 1);
                      g.addEdge(nodeNumber, nodeKey, 1);
                  }//end if
              }//end if
          }
		  else
	      //There is no node at this index
		  {
              map[j][k] = -1;
          }//end if
      }//end inner for
	}//end outer for
}//end mapMazeToGraph

void maze::findPathNonRec(graph &g)
//Finds a path through the given graph non-recursively,
//if a path exists.
{
	//Variables to track current location in maze
    int currentX = 0;
    int currentY = 0;

	//Boolean variable to end do while loop
    bool mazeComplete = false;

    do 
	{
		//Print current maze
		print(rows,cols,currentX,currentY);

		//Evaluate if the maze has been completed
		if (currentX == rows-1 && cols-1 == currentY)
		{
			cout << "Maze has been completed.\n";
			mazeComplete = true;
			continue;
		}//end if

		//Get current node
		int currentNode = getMap(currentX, currentY);

		//Mark current node as visited
		g.visit(currentNode);

		//Variable to store index of next node
		int nextNode;

	    //If we are not at the right-side bound
		if (currentY+1 < cols)
		{
			//Retrieve the node to the right of the current location
			nextNode = getMap(currentX, currentY+1);

			//If the node is valid, and has not been visited or marked:
			if ((nextNode != -1) && !g.getNode(nextNode).isMarked() && !g.getNode(nextNode).isVisited())
			{
				cout << "Go right\n";
				currentY++;
				continue;
			}//end if
		}//end if

		//If we are not at the bottom bound
		if (currentX+1 < rows)
		{
			//Retrieve the node underneath the current location
			nextNode = getMap(currentX+1, currentY);

			//If the node is valid, and has not been visited or marked:
			if ((nextNode != -1) && !g.getNode(nextNode).isVisited() && !g.getNode(nextNode).isMarked())
			{
				cout << "Go down\n";
				currentX++;
				continue;
			}//end if
		}//end if

		//Check that we are not at the left-side bound
		if (currentY > 0)
		{
			nextNode = getMap(currentX, currentY-1);

			//If the node is valid, and has not been visited or marked:
			if ((nextNode != -1) && !g.getNode(nextNode).isMarked() && !g.getNode(nextNode).isVisited())
			{
				cout << "Go left\n";
				currentY--;
				continue;
			}//end if
		}//end if

		//Check that we are not at the upper bound
		if (currentX > 0)
		{
			nextNode = getMap(currentX-1, currentY);

			//If the node is valid, and has not been visited or marked:
			if ((nextNode != -1) && !g.getNode(nextNode).isMarked() && !g.getNode(nextNode).isVisited())
			{
				cout << "Go up\n";
				currentX--;
				continue;
			}//end if
		}//end if
		
		//All nodes have been visited - mark current node as dead-end
		 g.getNode(currentNode).mark();

		//Check for neighbor vertices that have not been marked
		if (currentY+1 < cols)
		{
			nextNode = getMap(currentX, currentY+1);
			if ((nextNode != -1) && !g.getNode(nextNode).isMarked())
			{
				cout << "Go right\n";
				currentY++;
				continue;
			}//end if
		}//end if

		if (currentX+1 < rows)
		{
			nextNode = getMap(currentX+1, currentY);
			if ((nextNode != -1) && !g.getNode(nextNode).isMarked())
			{
				cout << "Go down\n";
				currentX++;
				continue;
			}//end if
		}//end if

		if (currentY > 0)
		{
			nextNode = getMap(currentX, currentY-1);
			if ((nextNode != -1) && !g.getNode(nextNode).isMarked())
			{
				cout << "Go left\n";
				currentY--;
				continue;
			}//end if
		}//end if

		if (currentX > 0)
		{
			nextNode = getMap(currentX-1, currentY);
			if ((nextNode != -1) && !g.getNode(nextNode).isMarked())
			{
				cout << "Go up\n";
				currentX--;
				continue;
			}//end if
		}//end if
        cout << "No path exists\n" << endl;
	    break;
    }while(!mazeComplete); //end do-while
}//end findPathNonRec

void maze::findPath(int currentX, int currentY, graph &g)
//Finds a path through the given graph recursively,
//if a path exists.
{
	//Print current maze
    print(rows,cols,currentX,currentY);

	//Evaluate if end of maze has been reached
    if (currentX == rows-1 && cols-1 == currentY)
    {
        cout << "Maze has been completed.";
        return;
    }//end if

	//Get current node and mark as visited
    int currentNode = getMap(currentX, currentY);
    g.visit(currentNode);

	//Variable to hold index of next node
    int nextNode;

	//If we are not at the right-side bound:
    if (currentY+1 < cols)
    {
		//Get next node. If valid, call function with this node
		nextNode = getMap(currentX, currentY+1);

		if ((nextNode != -1) && !g.getNode(nextNode).isMarked() && !g.getNode(nextNode).isVisited())
		{
			cout << "Go right\n";
			findPath(currentX, currentY+1, g);
			return;
		}//end if
    }//end if

	//If we are not at the bottom bound:
    if (currentX+1 < rows)
    {
		//Get next node. If valid, call function with this node
		nextNode = getMap(currentX+1, currentY);

		if ((nextNode != -1) && !g.getNode(nextNode).isVisited() && !g.getNode(nextNode).isMarked())
		{
			cout << "Go down\n";
			findPath(currentX+1, currentY, g);
			return;
		}//end if
    }//end if

	//If we are not at the left bound:
    if (currentY > 0)
	{
		//Get next node. If valid, call function with this node
		nextNode = getMap(currentX, currentY-1);

		if ((nextNode != -1) && !g.getNode(nextNode).isMarked() && !g.getNode(nextNode).isVisited())
		{
			cout << "Go left\n";
			findPath(currentX, currentY-1, g);
			return;
		}//end if
    }//end if

	//If we are not at the top bound:
    if (currentX > 0)
	{
		//Get next node. If valid, call function with this node
		nextNode = getMap(currentX-1, currentY);

		if ((nextNode != -1) && !g.getNode(nextNode).isMarked() && !g.getNode(nextNode).isVisited())
		{
			cout << "Go up\n";
			findPath(currentX-1, currentY, g);
			return;
		}//end if
    }//end if

	//All nodes have been visited - mark current node as dead-end
	g.getNode(currentNode).mark();

	//Check for neighbor vertices that have not been marked

	//If we are not at the right bound:
    if (currentY+1 < cols)
	{
		//Get next node. If valid, call function with this node
		nextNode = getMap(currentX, currentY+1);

		if ((nextNode != -1) && !g.getNode(nextNode).isMarked())
		{
			cout << "Go right\n";
			findPath(currentX, currentY+1, g);
			return;
		}//end if
    }//end if

	//If we are not at the bottom bound:
    if (currentX+1 < rows)
    {
		//Get next node. If valid, call function with this node
		nextNode = getMap(currentX+1, currentY);

		if ((nextNode != -1) && !g.getNode(nextNode).isMarked())
		{
			cout << "Go down\n";
			findPath(currentX+1, currentY, g);
			return;
		}//end if
    }//end if

	//If we are not at the left bound:
    if (currentY > 0)
    {
		//Get next node. If valid, call function with this node
		nextNode = getMap(currentX, currentY-1);

		if ((nextNode != -1) && !g.getNode(nextNode).isMarked())
		{
			cout << "Go left\n";
			findPath(currentX, currentY-1, g);
			return;
		}//end if
    }//end if

	//If we are not at the top bound:
    if (currentX > 0)
    {
		//Get next node. If valid, call function with this node
		nextNode = getMap(currentX-1, currentY);

		if ((nextNode != -1) && !g.getNode(nextNode).isMarked())
		{
			cout << "Go up\n";
			findPath(currentX-1, currentY, g);
			return;
		}//end if
    }//end if
	cout << "No path exists" << endl;
	return;
}//end findPath


//End of header file.