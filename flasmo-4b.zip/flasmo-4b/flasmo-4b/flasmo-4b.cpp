// Rob Smookler, Sean Flaherty
// Project 4B

//This file contains the main function for part B of project 4,
//as well as the global function 'solvePuzzle.'

#include "stdafx.h"
#include "board.h"
#include <iostream>
#include <fstream>
#include <conio.h>

using namespace std;

//Global variables to hold amount of recursive calls to solvePuzzle for each puzzle
int puzzle1, puzzle2, puzzle3;

bool solvePuzzle(board& b, int puzzleNumber)
//Global function that will solve the Sudoku puzzle. For a given board
//and puzzle number, it will complete the board & calculate the amount of
//times the function has been called. Note: 'puzzleNumber' indicates which
//input board the function is acting upon.
{
	//Determine which puzzle we are working on
	if(puzzleNumber == 1)
	{
		puzzle1++;
	}
	else if(puzzleNumber == 2)
	{
		puzzle2++;
	}
	else if(puzzleNumber == 3)
	{
		puzzle3++;
	}//end if

	//i and j will hold the coordinates of the most-constrained empty cell
	int i, j;

    // If there are no blank cells, we are finished and can return
    if (b.isSolved())
	{
       return true; 
	}//end if

	//Find most-constrained empty cell - i and j change by reference
	b.findMostConstrainedCell(i, j);

	//Cycle through all possible digits. If a digit is legal(no conflicts),
	//Set the cell's value, remove its conflicts, and see if it leads to a solution.
	//Return if it does not.

	for(int x = 1; x <= 9; x++)
	{
		if(b.isLegal(i, j, x))
		{
			//Set cell with the value of digit x
			b.setCell(i,j, x);

			//See if this leads to a solution
			if(solvePuzzle(b, puzzleNumber))
			{
				return true;
			}//end if

			//Clear the cell's value, repopulate conflicts
			b.clearCell(i, j, x);	
		}//end if
	}//end for

	//If every digit has been tried, we backtrack and try a different cell
	return false;
}//end solvePuzzle

int _tmain(int argc, _TCHAR* argv[])
//The function initializes a board for each sudoku text file.
//If a solution exists, the completed board is printed along with
//the number of recursive calls needed to reach the solution.
{
   //Define three input streams to read from the text files.
   ifstream fin1, fin2, fin3;
   string fileName1 = "sudoku1.txt";
   string fileName2 = "sudoku2.txt";
   string fileName3 = "sudoku3.txt";

   //Open file 1
   fin1.open(fileName1.c_str());

   if (!fin1)
   {
      cerr << "Cannot open " << fileName1 << endl;
      exit(1);
   }//end if

   //Open file 2
   fin2.open(fileName2.c_str());

   if (!fin2)
   {
      cerr << "Cannot open " << fileName2 << endl;
      exit(1);
   }//end if

   //Open file 3 
   fin3.open(fileName3.c_str());

   if (!fin3)
   {
      cerr << "Cannot open " << fileName3 << endl;
      exit(1);
   }//end if

   //Boolean variables to determine if puzzle is solved
   bool puzzle_solved1, puzzle_solved2, puzzle_solved3;

   //Declare and initialize the three boards. If a solution is found,
   //print out the board and the number of recursive calls.

   //Board 1
   try
   {
      board b1(SquareSize);				   //Board declaration

      while (fin1 && fin1.peek() != 'Z')   //The character z terminates a puzzle file
      {
			
		  b1.initialize(fin1);             //Initialize board

		  //Determine if the puzzle is solved, and print out the result.
		  puzzle_solved1 = solvePuzzle(b1, 1);

		  if(puzzle_solved1)
		  {
			  b1.printBoard();
			  cout << "\n-----------------------------------\n";
			  cout << "Puzzle is solved.\n";
			  cout << "-----------------------------------\n";
			  cout << "Number of recursive calls: " << puzzle1;
			  cout << "\n-----------------------------------\n";
		  }
		  else
		  {
			  cout << "\n-----------------------------------\n";
			  cout << "Puzzle is not solved.\n";
			  cout << "-----------------------------------\n\n";
		  }//end if
      }//end while
   }
   catch  (indexRangeError &ex)
   {
      cout << ex.what() << endl;
      exit(1);
   }//end try-catch
   
   //Board 2
   try
   {
      board b2(SquareSize);				   //Board declaration

      while (fin2 && fin2.peek() != 'Z')   //The character z terminates a puzzle file
      {
			
		  b2.initialize(fin2);			   //Initialize board

		  //Determine if the puzzle is solved, and print out the result.
		  puzzle_solved2 = solvePuzzle(b2, 2);
	  
		  if(puzzle_solved2)
		  {
			  b2.printBoard();
			  cout << "\n-----------------------------------\n";
			  cout << "Puzzle is solved.\n";
			  cout << "-----------------------------------\n";
			  cout << "Number of recursive calls: " << puzzle2;
			  cout << "\n-----------------------------------\n";
		  }
		  else
		  {
			  cout << "\n-----------------------------------\n";
			  cout << "Puzzle is not solved.\n";
			  cout << "-----------------------------------\n\n";
		  }//end if
      }//end while
   }
   catch  (indexRangeError &ex)
   {
      cout << ex.what() << endl;
      exit(1);
   }//end try-catch

   //Board 3
   try
   {
      board b3(SquareSize);				   //Board declaration

      while (fin3 && fin3.peek() != 'Z')   //The character z terminates a puzzle file
      {
			
		  b3.initialize(fin3);			   //Initialize board

		  //Determine if the puzzle is solved, and print out the result.
		  puzzle_solved3 = solvePuzzle(b3, 3);

		  if(puzzle_solved3)
		  {
			  b3.printBoard();
			  cout << "-----------------------------------\n";
			  cout << "Puzzle is solved.\n";
			  cout << "-----------------------------------\n";
			  cout << "Number of recursive calls: " << puzzle3;
			  cout << "\n-----------------------------------\n";
		  }
		  else
		  {
			  cout << "\n---------------------------\n";
			  cout << "Puzzle is not solved.\n";
			  cout << "---------------------------\n\n";
		  }//end if
      }//end while
   }
   catch  (indexRangeError &ex)
   {
      cout << ex.what() << endl;
      exit(1);
   }//end try-catch
   
   //Compute and display the average number of recursive calls across the 3 puzzles
   int average_calls = (puzzle1 + puzzle2 + puzzle3) / 3;
   cout << "\n-----------------------------------\n";
   cout << "Average # of recursive calls: " << average_calls;
   cout << "\n-----------------------------------\n";

   //Wait for character input by user before terminating program
   cout << "Press any key to continue...";
   getch();
   
   return 0;
}//end main

//End of source file.

