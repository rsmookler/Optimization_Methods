// Rob Smookler, Sean Flaherty
// Project 3A

//This file contains the class declaration for dictionary,
//as well as its constructor, get functions, and th
//checkDictionary function.

#include <fstream>
#include <iostream>
#include <vector>
#include <string>

using namespace std;

class dictionary
{
public:
	dictionary(const string& fileName);		      //Constructor
	vector<string> getWords();				      //Return words vector
	void checkDictionary(string candidateString); //Check dictionary for string
private:
	vector<string> words;						  //List of words
};

dictionary::dictionary(const string& fileName)
//Constructor that opens the file with the filename
//sent to it. For each word in the file, it will push
//the word into the words vector.
{
	//Create an input file stream from the given filename
	ifstream fin;
	fin.open(fileName.c_str());

	//Variable to hold each word read from the file
	string read_word;

	//While the file is not empty, read a single word and store it in the vector
	while(!fin.eof())
	{
		fin >> read_word;
		words.push_back(read_word);
	}//end while
}//end dictionary constructor

vector<string> dictionary::getWords()
//Returns the vector containing the list of words.
{
	return words;
}//end getWords

void dictionary::checkDictionary(string candidateString)
//Iterates through the list of words to attempt to 
//find a match for the candidate string. If a match is found,
//the word is printed, and the dictionary is exited.
{
	for(int k = 0; k < words.size(); k++)
	{

		//If a match is found, print out the word and exit for-loop
		if (candidateString == words[k]) 
		{
			cout << words[k] << "\n";
			break;
		}//end if
	}//end for
}//end checkDictionary


//End of header file.